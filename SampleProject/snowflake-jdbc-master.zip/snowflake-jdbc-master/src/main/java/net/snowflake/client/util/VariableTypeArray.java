package net.snowflake.client.util;

public class VariableTypeArray
{
  public int[] intArr;
  public long[] longArr;

  public VariableTypeArray(int[] arr1, long[] arr2)
  {
    intArr = arr1;
    longArr = arr2;
  }
}
